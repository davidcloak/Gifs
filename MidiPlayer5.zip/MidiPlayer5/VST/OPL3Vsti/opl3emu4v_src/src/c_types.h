#include <stdarg.h>
#include <stddef.h>

/** Emulation context */
typedef struct opl3emu_data *opl3emu_context;
typedef const struct opl3emu_data *opl3emu_const_context;

